using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using RpMcp;

var builder = Host.CreateApplicationBuilder(args);

// CRITICAL for stdio: JSON-RPC travels on stdout, so ALL logs must go to stderr.
// A single log line on stdout corrupts the protocol and the client sees nothing.
builder.Logging.AddConsole(o => o.LogToStandardErrorThreshold = LogLevel.Trace);

var baseUrl = Environment.GetEnvironmentVariable("RP_MCP_BASEURL") ?? "http://localhost:5000";
var catalogPath = Environment.GetEnvironmentVariable("RP_MCP_CATALOG") ?? "ntt_qctrl_seeting.json";

// Safety switches. Defaults are SAFE: writes off, raw writes off.
//   RP_MCP_READONLY  : unset/1/true => read-only (default). Set to 0/false to allow writes.
//   RP_MCP_ALLOW_RAW : unset/0/false => raw absolute-address writes disabled (default).
var readOnly = Flag("RP_MCP_READONLY", defaultValue: true);
var allowRaw = Flag("RP_MCP_ALLOW_RAW", defaultValue: false);

builder.Services.AddSingleton(new McpConfig(readOnly, allowRaw));
builder.Services.AddSingleton(_ => RegisterCatalog.Load(catalogPath));

builder.Services.AddHttpClient<RpApiClient>(c =>
{
    c.BaseAddress = new Uri(baseUrl);
    c.Timeout = TimeSpan.FromSeconds(15);
});

builder.Services
    .AddMcpServer()
    .WithStdioServerTransport()
    .WithToolsFromAssembly();

await builder.Build().RunAsync();

static bool Flag(string name, bool defaultValue)
{
    var v = Environment.GetEnvironmentVariable(name);
    if (string.IsNullOrWhiteSpace(v)) return defaultValue;
    return v == "1"
        || v.Equals("true", StringComparison.OrdinalIgnoreCase)
        || v.Equals("yes", StringComparison.OrdinalIgnoreCase);
}
