# RpMcp — MCP server for SharpRPL / WebServer.FourDevice

A stdio MCP server that drives your existing FourDevice HTTP API + `/ws/wave`.
It does **not** touch your server code — it's a separate client, a sibling to the browser UI.

## Tools

| Tool | Endpoint it drives |
|---|---|
| `get_status` | `GET /api/status` |
| `list_sessions` | `GET /api/devices/sessions` |
| `open_device` | `POST /api/devices/open` |
| `close_device` | `POST /api/devices/{id}/close` |
| `set_active` | `POST /api/devices/active` |
| `get_output` | `GET /api/output/status` |
| `configure_output` | `POST /api/output/{ch}/configure` (raw JSON body) |
| `list_registers` / `describe` | catalog only (no server needed) |
| `read_named` / `write_named` | `POST /api/device/memory/read|write` + catalog encode/decode |
| `read_raw` / `write_raw` | `POST /api/device/memory/read|write` (absolute address) |
| `acquire` | `WS /ws/wave` (parses one packet) |

## Build

```bash
# put the RpMcp folder next to your solution, then:
cd RpMcp
dotnet restore
dotnet build
```

## Configure

Two environment variables:

- `RP_MCP_BASEURL` — where FourDevice listens, e.g. `http://localhost:5000`
- `RP_MCP_CATALOG` — absolute path to `ntt_qctrl_seeting.json`

## Verify in order (each level assumes the one above passed)

**L0 — server starts / tools list.** No hardware, no FourDevice needed.
```bash
npx @modelcontextprotocol/inspector \
  -e RP_MCP_BASEURL=http://localhost:5000 \
  -e RP_MCP_CATALOG=/abs/path/ntt_qctrl_seeting.json \
  dotnet run --project /abs/path/RpMcp
```
Inspector should connect and list all tools. If not, the problem is registration/stdout — check that logs go to stderr.

**L1 — catalog loads/resolves.** Still no server.
Call `list_registers` with filter `PI_`, then `describe PI_SET_KP`.
Expect `PI_SET_KP -> 0x40330108, type float`. This validates the catalog path + parsing.

**L2 — HTTP wiring.** Start FourDevice (`dotnet run` on WebServer.FourDevice).
Call `get_status`. Expect a `200` and the status JSON.

**L3 — memory read + decode.** `open_device rp-1 <ip> 9000`, then `read_named rp-1 PI_SET_KP`.
Compare the decoded value against the same register in your PyRPL GUI.

**L4 — round-trip encode.** `write_named rp-1 LPF2_ALPHA 0.5`, then `read_named rp-1 LPF2_ALPHA`.
`0.5` in `Q1.23` must encode to `0x00400000`. Confirm in the GUI.

**L5 — acquire.** `acquire rp-1`. Expect `magicOk=true` and a `decimation` matching the GUI.

## Register with your agent

Claude Code:
```bash
claude mcp add rp -- dotnet run --project /abs/path/RpMcp
# then set the two env vars in the generated config, or use published exe below
```

OpenCode / generic stdio client — add to its MCP config:
```json
{
  "mcpServers": {
    "rp": {
      "command": "dotnet",
      "args": ["run", "--project", "/abs/path/RpMcp"],
      "env": {
        "RP_MCP_BASEURL": "http://localhost:5000",
        "RP_MCP_CATALOG": "/abs/path/ntt_qctrl_seeting.json"
      }
    }
  }
}
```

For a faster launch, publish a self-contained exe and point `command` at it instead of `dotnet run`:
```bash
dotnet publish -c Release -o ./publish
# command: /abs/path/RpMcp/publish/RpMcp
```

## Two assumptions to confirm against your server

1. **`memory/read` response shape.** `read_named` looks for a `value` field (hex string or number)
   in the read response. If your endpoint names it differently, fix the property name in
   `RpApiClient.TryExtractValue`.
2. **`configure_output` body.** The image didn't show the schema, so `configure_output` forwards a
   raw JSON string you supply. Once you know the fields, you can give it typed parameters.
