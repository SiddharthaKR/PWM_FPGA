using System.Globalization;
using System.Net.WebSockets;
using System.Text;
using System.Text.Json;

namespace RpMcp;

/// <summary>Thin client over the FourDevice HTTP API plus the /ws/wave stream.</summary>
public sealed class RpApiClient
{
    private readonly HttpClient _http;
    public RpApiClient(HttpClient http) => _http = http;

    private static readonly JsonSerializerOptions J = new(JsonSerializerDefaults.Web);

    public async Task<string> GetAsync(string path, CancellationToken ct)
    {
        var r = await _http.GetAsync(path, ct);
        var body = await r.Content.ReadAsStringAsync(ct);
        return $"{(int)r.StatusCode} {r.ReasonPhrase}\n{body}";
    }

    public async Task<string> PostJsonAsync(string path, object? body, CancellationToken ct)
    {
        var payload = body is null ? "{}" : JsonSerializer.Serialize(body, J);
        using var content = new StringContent(payload, Encoding.UTF8, "application/json");
        var r = await _http.PostAsync(path, content, ct);
        var resp = await r.Content.ReadAsStringAsync(ct);
        return $"{(int)r.StatusCode} {r.ReasonPhrase}\n{resp}";
    }

    public async Task<string> PostRawAsync(string path, string rawJson, CancellationToken ct)
    {
        var payload = string.IsNullOrWhiteSpace(rawJson) ? "{}" : rawJson;
        using var content = new StringContent(payload, Encoding.UTF8, "application/json");
        var r = await _http.PostAsync(path, content, ct);
        var resp = await r.Content.ReadAsStringAsync(ct);
        return $"{(int)r.StatusCode} {r.ReasonPhrase}\n{resp}";
    }

    /// <summary>POST /api/device/memory/read. Returns the raw HTTP response and a parsed 32-bit value if present.</summary>
    public async Task<(string raw, uint? value)> MemoryReadAsync(string deviceId, string addressHex, CancellationToken ct)
    {
        var resp = await PostJsonAsync(
            $"/api/device/memory/read?deviceId={Uri.EscapeDataString(deviceId)}",
            new { address = addressHex }, ct);
        return (resp, TryExtractValue(resp));
    }

    /// <summary>POST /api/device/memory/write with a 32-bit hex word.</summary>
    public Task<string> MemoryWriteAsync(string deviceId, string addressHex, string valueHex, CancellationToken ct)
        => PostJsonAsync(
            $"/api/device/memory/write?deviceId={Uri.EscapeDataString(deviceId)}",
            new { address = addressHex, value = valueHex }, ct);

    // ASSUMPTION: the memory/read response contains a "value" field (hex string or number).
    // If your server names it differently, adjust the property name here.
    private static uint? TryExtractValue(string httpResp)
    {
        int nl = httpResp.IndexOf('\n');
        if (nl < 0) return null;
        var json = httpResp[(nl + 1)..].Trim();
        if (json.Length == 0) return null;
        try
        {
            using var doc = JsonDocument.Parse(json);
            if (doc.RootElement.ValueKind == JsonValueKind.Object &&
                doc.RootElement.TryGetProperty("value", out var v))
            {
                if (v.ValueKind == JsonValueKind.String &&
                    RegisterCatalog.TryParseUint(v.GetString() ?? "", out var u)) return u;
                if (v.ValueKind == JsonValueKind.Number && v.TryGetUInt32(out var n)) return n;
            }
        }
        catch { /* not JSON, or unexpected shape */ }
        return null;
    }

    /// <summary>Connect to /ws/wave, read exactly one framed packet, parse and return it.</summary>
    public async Task<AcquireResult> AcquireAsync(string deviceId, TimeSpan timeout, CancellationToken ct)
    {
        var b = _http.BaseAddress!;
        var wsScheme = b.Scheme == "https" ? "wss" : "ws";
        var wsUri = new Uri($"{wsScheme}://{b.Authority}/ws/wave?deviceId={Uri.EscapeDataString(deviceId)}");

        using var cts = CancellationTokenSource.CreateLinkedTokenSource(ct);
        cts.CancelAfter(timeout);

        using var ws = new ClientWebSocket();
        await ws.ConnectAsync(wsUri, cts.Token);

        var buffer = new byte[64 * 1024];
        using var ms = new MemoryStream();
        WebSocketReceiveResult res;
        do
        {
            res = await ws.ReceiveAsync(buffer, cts.Token);
            if (res.MessageType == WebSocketMessageType.Close)
                throw new InvalidOperationException("WebSocket closed before a packet arrived.");
            ms.Write(buffer, 0, res.Count);
        } while (!res.EndOfMessage);

        try { await ws.CloseAsync(WebSocketCloseStatus.NormalClosure, "done", CancellationToken.None); }
        catch { /* best effort */ }

        return ParsePacket(ms.ToArray());
    }

    // Packet (little-endian): magic u32 | seq u32 | channel u16 | decimation u16 | reserved u32 | int16[] data
    private static AcquireResult ParsePacket(byte[] p)
    {
        if (p.Length < 16) throw new InvalidOperationException($"Packet too short: {p.Length} bytes.");
        uint magic = BitConverter.ToUInt32(p, 0);
        uint seq = BitConverter.ToUInt32(p, 4);
        ushort channel = BitConverter.ToUInt16(p, 8);
        ushort decimation = BitConverter.ToUInt16(p, 10);
        int nSamples = (p.Length - 16) / 2;
        var samples = new short[nSamples];
        Buffer.BlockCopy(p, 16, samples, 0, nSamples * 2);
        return new AcquireResult(magic, seq, channel, decimation, samples);
    }
}

public sealed record AcquireResult(uint Magic, uint Sequence, ushort Channel, ushort Decimation, short[] Samples);
