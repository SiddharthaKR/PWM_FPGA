using System.ComponentModel;
using System.Text.Json;
using ModelContextProtocol.Server;

namespace RpMcp;

/// <summary>Runtime safety switches, read from environment in Program.cs.</summary>
public sealed record McpConfig(bool ReadOnly, bool AllowRaw);

[McpServerToolType]
public sealed class RpTools
{
    private readonly RpApiClient _api;
    private readonly RegisterCatalog _cat;
    private readonly McpConfig _cfg;

    public RpTools(RpApiClient api, RegisterCatalog cat, McpConfig cfg)
    {
        _api = api;
        _cat = cat;
        _cfg = cfg;
    }

    private static readonly JsonSerializerOptions Pretty = new() { WriteIndented = true };
    private static string Deny(string reason) => JsonSerializer.Serialize(new { denied = true, reason });
    private static bool IsReadOnly(RegEntry r) => r.Access.Equals("ro", StringComparison.OrdinalIgnoreCase);
    private static string RangeHint(RegEntry r) =>
        (r.Min.HasValue || r.Max.HasValue) ? $" (allowed: {r.Min?.ToString() ?? "-inf"} .. {r.Max?.ToString() ?? "+inf"})" : "";

    // ---------- session / discovery (always allowed) ----------

    [McpServerTool, Description("Get overall server status: device state, sessions, active device, packet info, output states.")]
    public Task<string> get_status(CancellationToken ct)
        => _api.GetAsync("/api/status", ct);

    [McpServerTool, Description("List registered device sessions and the active deviceId.")]
    public Task<string> list_sessions(CancellationToken ct)
        => _api.GetAsync("/api/devices/sessions", ct);

    [McpServerTool, Description("Open a session to a Red Pitaya. targetPort is usually 9000.")]
    public Task<string> open_device(
        [Description("Logical device id, e.g. 'rp-1'")] string deviceId,
        [Description("Red Pitaya IP, e.g. '192.168.128.125'")] string targetHost,
        [Description("TCP port, usually 9000")] int targetPort,
        CancellationToken ct)
        => _api.PostJsonAsync("/api/devices/open", new { deviceId, targetHost, targetPort }, ct);

    [McpServerTool, Description("Close a device session.")]
    public Task<string> close_device(
        [Description("Device id")] string deviceId, CancellationToken ct)
        => _api.PostJsonAsync($"/api/devices/{Uri.EscapeDataString(deviceId)}/close", null, ct);

    [McpServerTool, Description("Switch the active device session (UI selection sync).")]
    public Task<string> set_active(
        [Description("Device id")] string deviceId, CancellationToken ct)
        => _api.PostJsonAsync("/api/devices/active", new { deviceId }, ct);

    // ---------- output / generator (write-gated) ----------

    [McpServerTool, Description("Get output/generator status for a device (active device if omitted).")]
    public Task<string> get_output(
        [Description("Device id, optional")] string? deviceId, CancellationToken ct)
        => _api.GetAsync(
            deviceId is null ? "/api/output/status"
                             : $"/api/output/status?deviceId={Uri.EscapeDataString(deviceId)}", ct);

    [McpServerTool, Description("Configure output on channel 1 or 2. Blocked in read-only mode; dry-run unless commit=true. Pass the request body as a raw JSON string matching the server's output-configure schema.")]
    public Task<string> configure_output(
        [Description("Channel: 1 or 2")] int channel,
        [Description("Device id")] string deviceId,
        [Description("Raw JSON body for the configure endpoint")] string configJson,
        [Description("Actually send it (false = preview only)")] bool commit = false,
        CancellationToken ct = default)
    {
        if (_cfg.ReadOnly)
            return Task.FromResult(Deny("server is READ-ONLY (RP_MCP_READONLY). Set RP_MCP_READONLY=0 to enable output changes."));
        if (!commit)
            return Task.FromResult(JsonSerializer.Serialize(new { action = "dry-run", channel, deviceId, body = configJson, note = "not sent — call again with commit=true" }));
        return _api.PostRawAsync($"/api/output/{channel}/configure?deviceId={Uri.EscapeDataString(deviceId)}", configJson, ct);
    }

    // ---------- named register catalog ----------

    [McpServerTool, Description("List known named registers. Optional case-insensitive substring filter, e.g. 'PI_' or 'BPF'. Shows type, format, range, and access.")]
    public string list_registers([Description("Optional name filter")] string? filter = null)
    {
        IEnumerable<string> names = _cat.Registers.Keys;
        if (!string.IsNullOrWhiteSpace(filter))
            names = names.Where(n => n.Contains(filter, StringComparison.OrdinalIgnoreCase));

        var items = names.OrderBy(n => n, StringComparer.Ordinal).Select(n =>
        {
            var r = _cat.Registers[n];
            _cat.TryResolveAddress(n, out var hex);
            return new { name = n, address = hex, type = r.Type, format = r.Format, min = r.Min, max = r.Max, access = r.Access };
        });
        return JsonSerializer.Serialize(items, Pretty);
    }

    [McpServerTool, Description("Describe one register: resolved address, type, Q-format, range, access, and default/safe value.")]
    public string describe([Description("Register name, e.g. 'PI_SET_KP'")] string name)
    {
        if (_cat.Registers.TryGetValue(name, out var r))
        {
            _cat.TryResolveAddress(name, out var hex);
            return JsonSerializer.Serialize(
                new { name, address = hex, type = r.Type, format = r.Format, min = r.Min, max = r.Max, access = r.Access, @default = r.Default, safe = r.Safe }, Pretty);
        }
        if (_cat.Aliases.TryGetValue(name, out var a))
            return JsonSerializer.Serialize(
                new { name, address = a, type = "uint32", note = "alias only (no register entry); treated as uint32" }, Pretty);
        return $"Unknown register '{name}'.";
    }

    [McpServerTool, Description("Read a register by NAME. Resolves the address, reads via the memory API, and decodes using the register's type/Q-format.")]
    public async Task<string> read_named(
        [Description("Device id")] string deviceId,
        [Description("Register name, e.g. 'PI_SET_KP'")] string name,
        CancellationToken ct)
    {
        if (!_cat.TryResolveAddress(name, out var hex))
            return $"Unknown register/alias '{name}'.";

        var (raw, val) = await _api.MemoryReadAsync(deviceId, hex, ct);
        if (val is null)
            return $"Read {name} @ {hex}: could not parse a value from the server response.\n{raw}";

        string decoded = _cat.Registers.TryGetValue(name, out var reg)
            ? _cat.UnpackValue(reg, val.Value)
            : val.Value.ToString();

        return JsonSerializer.Serialize(new { name, address = hex, raw = $"0x{val:X8}", value = decoded });
    }

    [McpServerTool, Description("Write a register by NAME. SAFE BY DEFAULT: this is a dry-run unless commit=true. Refuses read-only registers, range-checks the value against the catalog, and encodes per type/Q-format. For q/float pass a decimal like '1.5'; for uint32 pass decimal or 0x-hex.")]
    public async Task<string> write_named(
        [Description("Device id")] string deviceId,
        [Description("Register name, e.g. 'LPF2_ALPHA'")] string name,
        [Description("Value in engineering units (decimal for q/float; decimal or 0x-hex for uint32)")] string value,
        [Description("Actually write it (false = preview only)")] bool commit = false,
        CancellationToken ct = default)
    {
        if (_cfg.ReadOnly)
            return Deny("server is READ-ONLY (RP_MCP_READONLY). Set RP_MCP_READONLY=0 to enable writes.");
        if (!_cat.TryResolveAddress(name, out var hex))
            return $"Unknown register/alias '{name}'.";

        RegEntry reg = _cat.Registers.TryGetValue(name, out var r)
            ? r
            : new RegEntry(name, "uint32", null, null, null, null, "rw", null);

        if (IsReadOnly(reg))
            return Deny($"'{name}' is read-only (access=ro) and cannot be written.");
        if (!_cat.TryValidate(reg, value, out var parsed, out var verr))
            return Deny($"{name}: {verr}{RangeHint(reg)}");

        uint word;
        try { word = _cat.PackValue(reg, value); }
        catch (Exception ex) { return Deny($"encode error for {name}: {ex.Message}"); }

        var valueHex = $"0x{word:X8}";
        if (!commit)
            return JsonSerializer.Serialize(new { action = "dry-run", name, address = hex, type = reg.Type, format = reg.Format, value = parsed, encoded = valueHex, note = "not written — call again with commit=true" });

        var resp = await _api.MemoryWriteAsync(deviceId, hex, valueHex, ct);
        return JsonSerializer.Serialize(new { action = "write", name, address = hex, wrote = valueHex, server = resp });
    }

    // ---------- raw memory (double-gated) ----------

    [McpServerTool, Description("Raw memory read at an absolute hex address (for stock PyRPL registers not in the catalog).")]
    public async Task<string> read_raw(
        [Description("Device id")] string deviceId,
        [Description("Hex address, e.g. 0x40300100")] string address,
        CancellationToken ct)
    {
        var (raw, val) = await _api.MemoryReadAsync(deviceId, address, ct);
        return val is null ? raw : JsonSerializer.Serialize(new { address, raw = $"0x{val:X8}", value = val.Value });
    }

    [McpServerTool, Description("Raw memory write at an absolute hex address. DISABLED unless RP_MCP_ALLOW_RAW=1, blocked in read-only mode, and dry-run unless commit=true. No catalog protection — no range or access checks — use only while watching the board.")]
    public async Task<string> write_raw(
        [Description("Device id")] string deviceId,
        [Description("Hex address, e.g. 0x40300100")] string address,
        [Description("32-bit value, hex or decimal")] string value,
        [Description("Actually write it (false = preview only)")] bool commit = false,
        CancellationToken ct = default)
    {
        if (_cfg.ReadOnly)
            return Deny("server is READ-ONLY (RP_MCP_READONLY).");
        if (!_cfg.AllowRaw)
            return Deny("raw writes are disabled. Set RP_MCP_ALLOW_RAW=1 to enable (debug only, no safety checks).");
        if (!RegisterCatalog.TryParseUint(value, out var u))
            return Deny($"cannot parse value '{value}'.");

        var valueHex = $"0x{u:X8}";
        if (!commit)
            return JsonSerializer.Serialize(new { action = "dry-run", address, encoded = valueHex, note = "not written — call again with commit=true" });
        return await _api.MemoryWriteAsync(deviceId, address, valueHex, ct);
    }

    // ---------- recovery ----------

    [McpServerTool, Description("Write every WRITABLE register back to its known-good value from the catalog (the 'safe' field, else 'value'). SAFE BY DEFAULT: dry-run unless commit=true. Optional name filter (e.g. 'BPF'). Use this to return the board to a sane state after an error.")]
    public async Task<string> reset_to_safe(
        [Description("Device id")] string deviceId,
        [Description("Optional name filter, e.g. 'BPF'")] string? filter = null,
        [Description("Actually write the values (false = preview only)")] bool commit = false,
        CancellationToken ct = default)
    {
        if (_cfg.ReadOnly)
            return Deny("server is READ-ONLY (RP_MCP_READONLY). Set RP_MCP_READONLY=0 to allow reset.");

        var plan = new List<object>();
        foreach (var kv in _cat.Registers.OrderBy(k => k.Key, StringComparer.Ordinal))
        {
            var name = kv.Key;
            var reg = kv.Value;
            if (IsReadOnly(reg)) continue;
            var safeVal = reg.Safe ?? reg.Default;
            if (safeVal is null) continue;
            if (!string.IsNullOrWhiteSpace(filter) && !name.Contains(filter, StringComparison.OrdinalIgnoreCase)) continue;
            if (!_cat.TryResolveAddress(name, out var hex)) continue;

            uint word;
            try { word = _cat.PackValue(reg, safeVal); }
            catch { continue; }
            var vhex = $"0x{word:X8}";

            if (commit)
            {
                await _api.MemoryWriteAsync(deviceId, hex, vhex, ct);
                plan.Add(new { name, address = hex, wrote = vhex, value = safeVal });
            }
            else
            {
                plan.Add(new { name, address = hex, would = vhex, value = safeVal });
            }
        }

        return JsonSerializer.Serialize(new
        {
            action = commit ? "reset" : "dry-run",
            count = plan.Count,
            registers = plan,
            note = commit ? "written" : "call again with commit=true"
        }, Pretty);
    }

    // ---------- acquisition (read-only, always allowed) ----------

    [McpServerTool, Description("Acquire one waveform frame over the WebSocket. Returns decimation and sample stats; set includeSamples=true to return the full int16 array.")]
    public async Task<string> acquire(
        [Description("Device id")] string deviceId,
        [Description("Return the full int16 sample array (large)")] bool includeSamples = false,
        [Description("Timeout in seconds")] int timeoutSeconds = 10,
        CancellationToken ct = default)
    {
        AcquireResult r;
        try { r = await _api.AcquireAsync(deviceId, TimeSpan.FromSeconds(timeoutSeconds), ct); }
        catch (Exception ex) { return $"Acquire failed: {ex.Message}"; }

        short min = short.MaxValue, max = short.MinValue;
        long sum = 0;
        foreach (var s in r.Samples) { if (s < min) min = s; if (s > max) max = s; sum += s; }
        double mean = r.Samples.Length == 0 ? 0 : (double)sum / r.Samples.Length;

        var payload = new Dictionary<string, object?>
        {
            ["deviceId"] = deviceId,
            ["magicOk"] = r.Magic == 0xDEADBEEF,
            ["sequence"] = r.Sequence,
            ["channel"] = r.Channel,
            ["decimation"] = r.Decimation,
            ["sampleCount"] = r.Samples.Length,
            ["min"] = r.Samples.Length == 0 ? null : min,
            ["max"] = r.Samples.Length == 0 ? null : max,
            ["mean"] = mean,
        };
        if (includeSamples) payload["samples"] = r.Samples;
        return JsonSerializer.Serialize(payload);
    }
}
