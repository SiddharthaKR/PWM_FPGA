using System.Globalization;
using System.Text.Json;

namespace RpMcp;

/// <summary>
/// Loads ntt_qctrl_seeting.json and turns named registers into raw 32-bit words.
///
/// Safety fields (all optional) per register entry:
///   "min" / "max" : allowed range in ENGINEERING units (q/float) or raw value (uint32)
///   "access"      : "rw" (default) or "ro" (never written)
///   "safe"        : known-good value used by reset_to_safe (falls back to "value")
///
/// Two-level indirection: a register's "address" holds an ALIAS NAME, and the
/// aliases block resolves that name to the real hex address.
/// </summary>
public sealed class RegisterCatalog
{
    public required string Endianness { get; init; }
    public required Dictionary<string, string> Aliases { get; init; }      // name -> "0x...."
    public required Dictionary<string, RegEntry> Registers { get; init; }  // name -> typed entry

    public static RegisterCatalog Load(string path)
    {
        var json = File.ReadAllText(path);
        using var doc = JsonDocument.Parse(json);
        var root = doc.RootElement;

        var endian = root.TryGetProperty("endianness", out var e) ? e.GetString() ?? "little" : "little";

        var aliases = new Dictionary<string, string>(StringComparer.Ordinal);
        if (root.TryGetProperty("aliases", out var al) && al.ValueKind == JsonValueKind.Object)
            foreach (var p in al.EnumerateObject())
                aliases[p.Name] = p.Value.GetString() ?? "";

        var regs = new Dictionary<string, RegEntry>(StringComparer.Ordinal);
        if (root.TryGetProperty("registers", out var rs) && rs.ValueKind == JsonValueKind.Array)
            foreach (var r in rs.EnumerateArray())
            {
                var name = r.GetProperty("address").GetString()!;   // "address" is an alias NAME
                var type = r.GetProperty("type").GetString()!;
                string? fmt = r.TryGetProperty("format", out var f) ? f.GetString() : null;
                string? def = ReadScalar(r, "value");
                string? safe = ReadScalar(r, "safe");
                double? min = r.TryGetProperty("min", out var mn) && mn.ValueKind == JsonValueKind.Number ? mn.GetDouble() : null;
                double? max = r.TryGetProperty("max", out var mx) && mx.ValueKind == JsonValueKind.Number ? mx.GetDouble() : null;
                string access = r.TryGetProperty("access", out var ac) ? (ac.GetString() ?? "rw") : "rw";
                regs[name] = new RegEntry(name, type, fmt, def, min, max, access, safe);
            }

        return new RegisterCatalog { Endianness = endian, Aliases = aliases, Registers = regs };
    }

    private static string? ReadScalar(JsonElement obj, string prop)
    {
        if (!obj.TryGetProperty(prop, out var v)) return null;
        return v.ValueKind == JsonValueKind.String ? v.GetString() : v.GetRawText();
    }

    /// <summary>Resolve a register/alias name to its hex address string.</summary>
    public bool TryResolveAddress(string name, out string hex)
    {
        if (Aliases.TryGetValue(name, out var a)) { hex = a; return true; }
        hex = "";
        return false;
    }

    /// <summary>Parse and range-check an intended value BEFORE it is encoded or sent.</summary>
    public bool TryValidate(RegEntry reg, string valueStr, out double parsed, out string? error)
    {
        parsed = 0;
        error = null;
        try
        {
            parsed = reg.Type is "q" or "float"
                ? double.Parse(valueStr, CultureInfo.InvariantCulture)
                : (TryParseUint(valueStr, out var u) ? u : throw new FormatException($"'{valueStr}' is not a uint32"));
        }
        catch (Exception ex) { error = ex.Message; return false; }

        if (reg.Min.HasValue && parsed < reg.Min.Value) { error = $"value {parsed} is below min {reg.Min.Value}"; return false; }
        if (reg.Max.HasValue && parsed > reg.Max.Value) { error = $"value {parsed} is above max {reg.Max.Value}"; return false; }
        return true;
    }

    /// <summary>Encode an engineering-units value into the raw 32-bit word to write.</summary>
    public uint PackValue(RegEntry reg, string valueStr)
    {
        switch (reg.Type)
        {
            case "q":
            {
                int frac = FracBits(reg.Format);
                double d = double.Parse(valueStr, CultureInfo.InvariantCulture);
                long scaled = (long)Math.Round(d * (1L << frac));
                return unchecked((uint)scaled);   // two's-complement into 32 bits
            }
            case "float":
            {
                float fv = float.Parse(valueStr, CultureInfo.InvariantCulture);
                return BitConverter.SingleToUInt32Bits(fv);   // IEEE-754
            }
            default: // "uint32"
            {
                if (TryParseUint(valueStr, out var u)) return u;
                throw new FormatException($"Cannot parse '{valueStr}' as uint32.");
            }
        }
    }

    /// <summary>Decode a raw 32-bit word back into engineering units (as a string).</summary>
    public string UnpackValue(RegEntry reg, uint raw)
    {
        switch (reg.Type)
        {
            case "q":
            {
                int frac = FracBits(reg.Format);
                int signed = unchecked((int)raw);
                double d = (double)signed / (1L << frac);
                return d.ToString("R", CultureInfo.InvariantCulture);
            }
            case "float":
                return BitConverter.UInt32BitsToSingle(raw).ToString("R", CultureInfo.InvariantCulture);
            default: // "uint32"
                return raw.ToString();
        }
    }

    // "Q15.16" -> 16 fractional bits ; "Q1.23" -> 23
    private static int FracBits(string? format)
    {
        if (string.IsNullOrWhiteSpace(format))
            throw new FormatException("q register is missing its 'format' (e.g. \"Q15.16\").");
        int dot = format.IndexOf('.');
        if (dot < 0) throw new FormatException($"Bad Q format '{format}'.");
        return int.Parse(format.AsSpan(dot + 1), NumberStyles.Integer, CultureInfo.InvariantCulture);
    }

    public static bool TryParseUint(string s, out uint value)
    {
        s = s.Trim();
        if (s.StartsWith("0x", StringComparison.OrdinalIgnoreCase))
            return uint.TryParse(s.AsSpan(2), NumberStyles.HexNumber, CultureInfo.InvariantCulture, out value);
        return uint.TryParse(s, NumberStyles.Integer, CultureInfo.InvariantCulture, out value);
    }
}

public sealed record RegEntry(
    string Name,
    string Type,
    string? Format,
    string? Default,
    double? Min,
    double? Max,
    string Access,
    string? Safe);
